data:extend({
  { type="bool-setting", name="todo_receiver_write_changelog", setting_type="runtime-global", default_value=true, order="a" },
  { type="bool-setting", name="todo_receiver_allow_external_meta", setting_type="runtime-global", default_value=true, order="b" }
})