Todo Receiver (Integration Bridge + GUI) — v0.4.0
- /todo add|update|complete (RCON-friendly)
- JSONL change log at script-output/todo/changes.jsonl
- Basic GUI: top button → panel with filters (status/priority/search), list, details (edit + complete)
