-- todo_receiver 0.4.0: /todo bridge + change-log + basic GUI
local CHANGELOG_PATH = "todo/changes.jsonl"
local LOG_PATH = "todo/integration_bridge.log"

script.on_init(function()
  global.tasks = global.tasks or {}
  global.next_id = global.next_id or 1
  global.ui = global.ui or {}
end)

script.on_configuration_changed(function()
  global.ui = global.ui or {}
  for _, p in pairs(game.players) do
    if p and p.valid then
      if p.gui.top["todo_rx_top_button"] then p.gui.top["todo_rx_top_button"].destroy() end
      p.gui.top.add{ type="sprite-button", name="todo_rx_top_button", sprite="utility/list_view", tooltip={"", "Todo Receiver"} }
      if p.gui.screen["todo_rx_main_frame"] then p.gui.screen["todo_rx_main_frame"].destroy() end
    end
  end
end)

script.on_event(defines.events.on_player_created, function(e)
  local p = game.get_player(e.player_index)
  if p and p.valid then
    if not p.gui.top["todo_rx_top_button"] then
      p.gui.top.add{ type="sprite-button", name="todo_rx_top_button", sprite="utility/list_view", tooltip={"", "Todo Receiver"} }
    end
  end
end)

local function write_log(line) game.write_file(LOG_PATH, line .. "\n", true) end
local function write_change(evt)
  local s = settings.global["todo_receiver_write_changelog"]
  if s and s.value then
    game.write_file(CHANGELOG_PATH, game.table_to_json(evt) .. "\n", true)
  end
end

local function ensure_meta(t) t.meta = t.meta or {}; return t.meta end
local function update_from_meta(t, meta)
  if not meta then return end
  local a = settings.global["todo_receiver_allow_external_meta"]
  if a and a.value then for k,v in pairs(meta) do ensure_meta(t)[k] = v end end
  if meta.title then t.title = meta.title end
  if meta.note then t.note = meta.note end
end

local function add_task(title, meta, who)
  local id = global.next_id; global.next_id = id + 1
  local t = { id=id, title=title or "(untitled)", note=(meta and meta.note) or "", status="open", meta={} }
  update_from_meta(t, meta); global.tasks[id] = t
  write_log(game.table_to_json({at=game.tick, action="add", id=id, title=t.title, by=who or "server"}))
  write_change({ op="add", localId=id, title=t.title, fields={ title=t.title, note=t.note, importance=t.meta and t.meta.importance or nil, categories=t.meta and t.meta.categories or nil, due=t.meta and t.meta.due or nil, dueTimeZone=t.meta and t.meta.dueTimeZone or nil }, by=who or "server" })
  return t
end

local function find_task_by_id(id) return global.tasks[id] end
local function find_task_by_externalId(externalId)
  if not externalId then return nil end
  for _,t in pairs(global.tasks) do if t.meta and t.meta.externalId == externalId then return t end end
  return nil
end

local function patch_task(t, meta, who)
  update_from_meta(t, meta)
  write_log(game.table_to_json({at=game.tick, action="update", id=t.id, by=who or "server"}))
  write_change({ op="update", externalId=t.meta and t.meta.externalId or nil, localId=t.id, fields=meta or {}, by=who or "server" })
end

local function complete_task(t, who)
  t.status = "done"
  write_log(game.table_to_json({at=game.tick, action="complete", id=t.id, by=who or "server"}))
  write_change({ op="complete", externalId=t.meta and t.meta.externalId or nil, localId=t.id, by=who or "server" })
end

local function extract_meta_param(text)
  local meta_start = string.find(text, "##meta=")
  if not meta_start then return text, nil end
  local title = string.sub(text, 1, meta_start - 1):gsub("%s+$","")
  local json_part = string.sub(text, meta_start + 7)
  local ok, tbl = pcall(game.json_to_table, json_part)
  if ok then return title, tbl else return title, nil end
end

commands.add_command("todo", "Todo Receiver: add|update|complete", function(event)
  local player = game.get_player(event.player_index)
  local who = player and ("player:"..player.name) or "server"
  local param = event.parameter or ""
  local action, rest = param:match("^(%S+)%s+(.+)$")

  if not action then if player then player.print({"", "[todo] Usage: /todo add <title> ##meta={...} | update <id|externalId> ##meta={...} | complete <id|externalId>"}) end return end

  if action == "add" then
    local title, meta = extract_meta_param(rest)
    local t = add_task(title, meta, who); if player then player.print({"", "[todo] Added #", t.id, ": ", t.title}) end
    if player then refresh_ui(player) end; return
  end

  if action == "update" then
    local idstr, meta_str = rest:match("^(%S+)%s+(.+)$"); if not idstr then if player then player.print("[todo] update requires id|externalId and ##meta") end return end
    local _, meta = extract_meta_param(meta_str); if not meta then if player then player.print("[todo] invalid or missing ##meta JSON") end return end
    local t = tonumber(idstr) and find_task_by_id(tonumber(idstr)) or find_task_by_externalId(idstr)
    if not t then t = add_task(meta.title or ("Task "..idstr), meta, who) else patch_task(t, meta, who) end
    if player then refresh_ui(player) end; return
  end

  if action == "complete" then
    local idstr = rest; local t = tonumber(idstr) and find_task_by_id(tonumber(idstr)) or find_task_by_externalId(idstr)
    if not t then if player then player.print("[todo] task not found") end return end
    complete_task(t, who); if player then player.print({"", "[todo] Completed #", t.id, ": ", t.title}) end; if player then refresh_ui(player) end; return
  end

  if player then player.print("[todo] Unknown action. Use add|update|complete.") end
end)

-- GUI helpers/state
local GUI = {
  top_button = "todo_rx_top_button",
  main_frame = "todo_rx_main_frame",
  filters_flow = "todo_rx_filters_flow",
  status_drop = "todo_rx_status_drop",
  imp_drop = "todo_rx_imp_drop",
  search = "todo_rx_search",
  list = "todo_rx_list",
  details = "todo_rx_details",
}

local function ui_state(p)
  global.ui[p.index] = global.ui[p.index] or { status="All", importance="All", search="", selected=nil }
  return global.ui[p.index]
end

function build_main_frame(p)
  local st = ui_state(p)
  if p.gui.screen[GUI.main_frame] then return end
  local root = p.gui.screen.add{ type="frame", name=GUI.main_frame, caption="Todo Receiver", direction="vertical" }
  root.auto_center = true

  local filters = root.add{ type="flow", name=GUI.filters_flow, direction="horizontal" }
  filters.clear()
  filters.add{ type="label", caption="Status:" }
  filters.add{ type="drop-down", name=GUI.status_drop, items={"All","Open","Done"}, selected_index=(st.status=="Open" and 2) or (st.status=="Done" and 3) or 1 }
  filters.add{ type="empty-widget", style="draggable_space" }.style.horizontally_stretchable = true
  filters.add{ type="label", caption="Priority:" }
  filters.add{ type="drop-down", name=GUI.imp_drop, items={"All","high","normal","low"}, selected_index=(st.importance=="high" and 2) or (st.importance=="normal" and 3) or (st.importance=="low" and 4) or 1 }
  filters.add{ type="textfield", name=GUI.search, text=st.search or "", tooltip="Search title/note" }

  local content = root.add{ type="flow", direction="horizontal" }
  local list_scroll = content.add{ type="scroll-pane" }
  list_scroll.style.maximal_height = 500
  list_scroll.style.minimal_width = 350

  local function matches_filters(t, st)
    if st.status == "Open" and t.status ~= "open" then return false end
    if st.status == "Done" and t.status ~= "done" then return false end
    if st.importance ~= "All" then
      local imp = t.meta and t.meta.importance or "normal"; if imp ~= st.importance then return false end
    end
    if st.search and #st.search > 0 then
      local s = string.lower(st.search)
      local hay = string.lower((t.title or "") .. " " .. (t.note or ""))
      if not string.find(hay, s, 1, true) then return false end
    end
    return true
  end

  local list = list_scroll.add{ type="table", name=GUI.list, column_count=1, draw_horizontal_lines=true }
  for _,t in pairs(global.tasks) do
    if matches_filters(t, st) then
      local cap = string.format("#%d  %s%s", t.id, t.title or "(untitled)", t.status=="done" and " ✔" or "")
      list.add{ type="button", name="todo_rx_sel_"..t.id, caption=cap, style="button" }
    end
  end

  local details = content.add{ type="frame", name=GUI.details, caption="Details", direction="vertical" }
  details.style.minimal_width = 350
  details.add{ type="label", caption="Select a task to view details." }
end

function refresh_ui(p)
  local st = ui_state(p)
  local root = p.gui.screen[GUI.main_frame]; if not (root and root.valid) then return end
  local filters = root[GUI.filters_flow]
  if filters and filters.valid then
    filters[GUI.status_drop].selected_index = (st.status=="Open" and 2) or (st.status=="Done" and 3) or 1
    filters[GUI.imp_drop].selected_index = (st.importance=="high" and 2) or (st.importance=="normal" and 3) or (st.importance=="low" and 4) or 1
    filters[GUI.search].text = st.search or ""
  end
  local content = root.children[2]
  local list_scroll = content.children[1]
  local list = list_scroll[GUI.list]; if list then list.destroy() end
  list = list_scroll.add{ type="table", name=GUI.list, column_count=1, draw_horizontal_lines=true }

  local function matches_filters(t, st)
    if st.status == "Open" and t.status ~= "open" then return false end
    if st.status == "Done" and t.status ~= "done" then return false end
    if st.importance ~= "All" then
      local imp = t.meta and t.meta.importance or "normal"; if imp ~= st.importance then return false end
    end
    if st.search and #st.search > 0 then
      local s = string.lower(st.search)
      local hay = string.lower((t.title or "") .. " " .. (t.note or ""))
      if not string.find(hay, s, 1, true) then return false end
    end
    return true
  end

  for _,t in pairs(global.tasks) do
    if matches_filters(t, st) then
      local cap = string.format("#%d  %s%s", t.id, t.title or "(untitled)", t.status=="done" and " ✔" or "")
      list.add{ type="button", name="todo_rx_sel_"..t.id, caption=cap, style="button" }
    end
  end

  local details = content[GUI.details]; details.clear()
  local t = st.selected and global.tasks[st.selected] or nil
  if not t then
    details.add{ type="label", caption="Select a task to view details." }
  else
    details.add{ type="label", caption=string.format("Task #%d", t.id) }.style.font = "heading-2"
    details.add{ type="textfield", name="todo_rx_title_edit", text=t.title or "" }.style.horizontally_stretchable = true
    details.add{ type="textfield", name="todo_rx_note_edit", text=t.note or "" }.style.horizontally_stretchable = true
    local meta_flow = details.add{ type="flow", direction="vertical" }
    meta_flow.add{ type="label", caption="externalId: "..(t.meta and (t.meta.externalId or "—") or "—") }
    meta_flow.add{ type="label", caption="importance: "..(t.meta and (t.meta.importance or "normal") or "normal") }
    meta_flow.add{ type="label", caption="due: "..(t.meta and (t.meta.due or "—") or "—") }
    local btn_flow = details.add{ type="flow", direction="horizontal" }
    btn_flow.add{ type="button", name="todo_rx_save", caption="Save" }
    btn_flow.add{ type="button", name="todo_rx_complete", caption="Complete" }
  end
end

script.on_event(defines.events.on_gui_click, function(e)
  local p = game.get_player(e.player_index); if not p then return end
  local el = e.element; if not (el and el.valid) then return end
  if el.name == GUI.top_button then
    if p.gui.screen[GUI.main_frame] then p.gui.screen[GUI.main_frame].destroy() else build_main_frame(p) end
    return
  end
  if string.sub(el.name,1,12) == "todo_rx_sel_" then
    local id = tonumber(string.sub(el.name,13))
    ui_state(p).selected = id
    refresh_ui(p); return
  end
  if el.name == "todo_rx_save" then
    local st = ui_state(p); if not st.selected then return end
    local t = global.tasks[st.selected]; if not t then return end
    local root = p.gui.screen[GUI.main_frame]; if not root then return end
    local details = root.children[2][GUI.details]
    local title_edit = details["todo_rx_title_edit"]; local note_edit = details["todo_rx_note_edit"]
    local meta = { title = title_edit and title_edit.text or nil, note = note_edit and note_edit.text or nil }
    patch_task(t, meta, "gui"); refresh_ui(p); return
  end
  if el.name == "todo_rx_complete" then
    local st = ui_state(p); if not st.selected then return end
    local t = global.tasks[st.selected]; if t then complete_task(t, "gui") end
    refresh_ui(p); return
  end
end)

script.on_event(defines.events.on_gui_selection_state_changed, function(e)
  local p = game.get_player(e.player_index); if not p then return end
  local el = e.element; if not (el and el.valid) then return end
  local st = ui_state(p)
  if el.name == GUI.status_drop then
    local items = {"All","Open","Done"}
    st.status = items[el.selected_index] or "All"; refresh_ui(p)
  elseif el.name == GUI.imp_drop then
    local items = {"All","high","normal","low"}
    st.importance = items[el.selected_index] or "All"; refresh_ui(p)
  end
end)

script.on_event(defines.events.on_gui_text_changed, function(e)
  local p = game.get_player(e.player_index); if not p then return end
  local el = e.element; if not (el and el.valid) then return end
  if el.name == GUI.search then
    ui_state(p).search = el.text or ""; refresh_ui(p)
  end
end)
